// In this class shows downloading file TestTimeInterface for cearing loop

public class TestTimes implements TestTimesInterface {

    private double[] arr = new double[10];
    private double[] memoryUsage = new double[10];
    private TimeUnits timeUnits;
    private MemoryUnits memoryUnits;
    private int counter = 0;

    @Override
    public void addTestTime(long runTime) {
        if (counter == 0) {
            reset();
        }
        if (counter < 10) {
            arr[counter++] = runTime;
        } else {
            for (int i = 0; i < 9; i++) {
                arr[i] = arr[i + 1];
            }
            arr[9] = runTime;
        }
    }

    @Override
    public double getAverageMemoryUsage() {
        double total = 0;
        if (counter > 0) {
            for (int i = 0; i < counter; i++) {
                total += memoryUsage[i];
            }
            return total / counter;
        }
        return 0;
    }

    @Override
    public double getAverageTestTime() {
        double total = 0;
        if (counter > 0) {
            for (int i = 0; i < counter; i++) {
                total += arr[i];
            }
            return total / counter;
        }
        return 0;
    }

    @Override
    public double getLastMemoryUsage() {
        if (counter > 0) {
            return memoryUsage[counter - 1];
        }
        return 0;
    }

    @Override
    public double getLastTestTime() {
        if (counter > 0) {
            return arr[counter - 1];
        }
        return 0;
    }

    @Override
    public MemoryUnits getMemoryUnits() {
        return memoryUnits;
    }

    @Override
    public double[] getMemoryUsages() {
        return memoryUsage;
    }

    @Override
    public double[] getTestTimes() {
        return arr;
    }

    @Override
    public TimeUnits getTimeUnits() {
        return timeUnits;
    }

    @Override
    public void resetTestTimes() {
        reset();
    }

    @Override
    public void setMemoryUnits(MemoryUnits memoryUnits) {
        this.memoryUnits = memoryUnits;
    }

    @Override
    public void setTimeUnits(TimeUnits timeUnits) {
        this.timeUnits = timeUnits;
    }

    private void reset() {
        for (int i = 0; i < 10; i++) {
            arr[i] = 0;
            memoryUsage[i] = 0;
        }
    }
}