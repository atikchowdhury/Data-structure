import java.util.Iterator;

public class ArrayBasedStack<E> implements StackInterface<E> {

    private int capacity = 10000;
    private Object[] arr = new Object[capacity];
    private int size = 0;

    @Override
    public void clear() {
        for (int i = size - 1; i >= 0; i--) {
            arr[i] = null;
        }
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E peek() {
        if (size != 0) {
            return (E) arr[size - 1];
        } else {
            return null;
        }
    }

    @Override
    public E pop() {
        if (size != 0) {
            E data = (E) arr[size - 1];
            size--;
            arr[size] = null;
            return data;
        } else {
            return null;
        }
    }

    @Override
    public void push(E e) throws IllegalStateException, NullPointerException {
        if (e == null) {
            throw new NullPointerException();
        } else if (size >= capacity) {
            throw new IllegalStateException();
        } else {
            arr[size++] = e;
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator<E>(this);
    }
}
