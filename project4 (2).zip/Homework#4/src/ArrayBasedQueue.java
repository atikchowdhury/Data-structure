import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayBasedQueue<E> implements QueueInterface<E> {

    private int capacity = 10000;
    private Object[] arr = new Object[capacity];
    private int size = 0;
    private int front = -1, rear = -1;

    @Override
    public E dequeue() {
        if (size == 0) {
            return null;
        } else {
            E data = (E) arr[front];
            arr[front] = null;
            if (front == rear) {
                front = -1;
                rear = -1;
            } else if (front == capacity - 1) {
                front = 0;
            } else {
                front++;
            }
            size--;
            if (size == 0) {
                front = rear = -1;
            }
            return data;
        }
    }

    @Override
    public E dequeue(int index) throws NoSuchElementException {
        if ((index > rear && rear > front) || (rear < front && index < front && index > rear)) {
            throw new NoSuchElementException();
        } else {
            E data = (E) arr[(front + index) % capacity];
            int i = (front + index) % capacity;
            while (i != rear) {
                arr[i] = arr[(i + 1) % capacity];
                i = (i + 1) % capacity;
            }
            rear = (rear - 1 + capacity) % capacity;
            size--;
            if (size == 0) {
                front = rear = -1;
            }
            return data;
        }
    }

    @Override
    public void enqueue(E e) throws IllegalStateException, NullPointerException {
        if (e == null) {
            throw new NullPointerException();
        } else if (size >= capacity) {
            throw new IllegalStateException();
        } else {
            if (front == -1) {
                front = rear = 0;
                arr[rear] = e;
            } else if (rear == capacity - 1 & front != 0) {
                rear = 0;
                arr[rear] = e;
            } else {
                arr[++rear] = e;
            }
            size++;
        }
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E peek() {
        if (front != -1) {
            return (E) arr[front];
        } else {
            return null;
        }
    }

    @Override
    public void removeAll() {
        for (int i = 0; i < capacity; i++) {
            arr[i] = null;
        }
        size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator<E>(this);
    }
}