import java.util.Iterator;

public class ElementIterator<E> implements Iterator<E> {
    private Object list;
    private int idx;

    ElementIterator(Object list) {
        this.list = list;
        this.idx = 0;
    }

    @Override
    public boolean hasNext() {
        if (list instanceof ArrayBasedQueue) {
            ArrayBasedQueue<E> aQueue = (ArrayBasedQueue<E>) list;
            if (idx < aQueue.size() && aQueue.peek() != null) {
                return true;
            } else {
                return false;
            }
        } else if (list instanceof ArrayBasedStack) {
            ArrayBasedStack<E> aStack = (ArrayBasedStack<E>) list;
            if (idx < aStack.size() && aStack.peek() != null) {
                return true;
            } else {
                return false;
            }
        } else if (list instanceof LinkedQueue) {
            LinkedQueue<E> lQueue = (LinkedQueue<E>) list;
            if (idx < lQueue.size() && lQueue.peek() != null) {
                return true;
            } else {
                return false;
            }
        } else if (list instanceof LinkedStack) {
            LinkedStack<E> lStack = (LinkedStack<E>) list;
            if (idx < lStack.size() && lStack.peek() != null) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    @Override
    public E next() {
        if (list instanceof ArrayBasedQueue) {
            ArrayBasedQueue<E> aQueue = (ArrayBasedQueue<E>) list;
            return aQueue.dequeue();
        } else if (list instanceof ArrayBasedStack) {
            ArrayBasedStack<E> aStack = (ArrayBasedStack<E>) list;
            return aStack.pop();
        } else if (list instanceof LinkedQueue) {
            LinkedQueue<E> lQueue = (LinkedQueue<E>) list;
            return lQueue.dequeue();
        } else if (list instanceof LinkedStack) {
            LinkedStack<E> lStack = (LinkedStack<E>) list;
            return lStack.pop();
        } else {
            return null;
        }
    }

}