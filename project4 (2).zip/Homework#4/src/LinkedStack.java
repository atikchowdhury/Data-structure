import java.util.Iterator;

public class LinkedStack<E> implements StackInterface<E> {

    private Node<E> head = null, curr = null;
    private int size = 0;

    @Override
    public void clear() {
        head = null;
        curr = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E peek() {
        if (size != 0) {
            return curr.getData();
        }
        return null;
    }

    @Override
    public E pop() {
        if (size != 0) {
            E data = curr.getData();
            if (curr.getPrevious() != null) {
                curr.getPrevious().setNext(null);
                curr = curr.getPrevious();
            }
            size--;
            if (size == 0) {
                head = null;
                curr = null;
            }
            return data;
        } else {
            return null;
        }
    }

    @Override
    public void push(E e) throws IllegalStateException, NullPointerException {
        if (e == null) {
            throw new NullPointerException();
        } else {
            Node<E> newnode = new Node<E>(e);
            if (size != 0) {
                newnode.setPrevious(curr);
                newnode.setNext(null);
                curr.setNext(newnode);
                curr = newnode;
            } else {
                head = newnode;
                curr = newnode;
                head.setNext(null);
                head.setPrevious(null);
            }
            size++;
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator<E>(this);
    }
}