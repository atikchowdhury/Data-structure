import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedQueue<E> implements QueueInterface<E> {

    private Node<E> head = null, curr = null;
    private int size = 0;

    @Override
    public E dequeue() {
        if (head != null) {
            E data = head.getData();
            if (head.getNext() != null) {
                Node<E> next = head.getNext();
                next.setPrevious(null);
                head = next;
            } else {
                head = null;
            }
            return data;
        } else {
            return null;
        }
    }

    @Override
    public E dequeue(int index) throws NoSuchElementException {
        if (index < 0 || index >= size) {
            throw new NoSuchElementException();
        } else {
            int idx = 0;
            Node<E> temp = head;
            while (idx != index) {
                idx++;
                temp = temp.getNext();
            }
            E data = temp.getData();
            if (temp.getPrevious() != null) {
                temp.getPrevious().setNext(temp.getNext());
            }
            if (temp.getNext() != null) {
                temp.getNext().setPrevious(temp.getPrevious());
            }
            return data;
        }
    }

    @Override
    public void enqueue(E e) throws IllegalStateException, NullPointerException {
        if (e == null) {
            throw new NullPointerException();
        } else {
            if (head == null) {
                head = new Node<E>(null, e, null);
                curr = head;
            } else {
                Node<E> newNode = new Node<E>(curr, e, null);
                curr.setNext(newNode);
                curr = newNode;
            }
            size++;
        }
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E peek() {
        if (head != null) {
            return head.getData();
        } else {
            return null;
        }
    }

    @Override
    public void removeAll() {
        head = curr = null;
        size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator<E>(this);
    }
}