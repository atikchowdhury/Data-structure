public class Driver implements DriverInterface {
    public static void main(String[] args) {
        Driver driver = new Driver();
        for (QueueTestType queueTestType : QueueTestType.values()) {
            System.out.println("Running Test: Queue " + queueTestType);
            for (QueueType queueType : QueueType.values()) {
                System.out.println(queueType);
                TestTimes testTimes = driver.runQueueTestCase(queueType, queueTestType, 10);
                printTestTimes(testTimes);
                printMemoryUsage(testTimes);
            }
        }

        for (StackTestType stackTestType : StackTestType.values()) {
            System.out.println("Running Test: Stack " + stackTestType);
            for (StackType stackType : StackType.values()) {
                System.out.println(stackType);
                TestTimes testTimes = driver.runStackTestCase(stackType, stackTestType, 10);
                printTestTimes(testTimes);
                printMemoryUsage(testTimes);
            }
        }
    }

    @Override
    public QueueInterface<String> createQueue(QueueType queueType, QueueTestType queueTestType) {
        QueueInterface<String> queue;
        if (queueType == QueueType.ArrayBasedQueue) {
            queue = new ArrayBasedQueue<String>();
        } else {
            queue = new LinkedQueue<String>();
        }
        if (queueTestType == QueueTestType.Dequeue || queueTestType == QueueTestType.Iterate) {
            for (int i = 1; i <= 10000; i++) {
                queue.enqueue("String " + i);
            }
        }
        return queue;
    }

    @Override
    public StackInterface<String> createStack(StackType stackType, StackTestType stackTestType) {
        StackInterface<String> stack;
        if (stackType == StackType.ArrayBasedStack) {
            stack = new ArrayBasedStack<String>();
        } else {
            stack = new LinkedStack<String>();
        }
        if (stackTestType == StackTestType.Pop || stackTestType == StackTestType.Iterate) {
            for (int i = 1; i <= 10000; i++) {
                stack.push("String " + i);
            }
        }
        return stack;
    }

    @Override
    public TestTimes runQueueTestCase(QueueType queueType, QueueTestType queueTestType, int numberOfTimes) {
        TestTimes testTimes = new TestTimes();
        double[] memoryUsages = testTimes.getMemoryUsages();
        for (int i = 0; i < numberOfTimes; i++) {
            QueueInterface<String> queue = createQueue(queueType, queueTestType);
            long st = System.nanoTime();
            if (queueTestType == QueueTestType.Enqueue) {
                for (int j = 1; j <= 10000; j++) {
                    queue.enqueue("String " + j);
                }
            } else if (queueTestType == QueueTestType.Dequeue) {
                for (int j = 1; j <= 10000; j++) {
                    queue.dequeue();
                }
            } else {
                ElementIterator<String> iterator = (ElementIterator<String>) queue.iterator();
                while (iterator.hasNext()) {
                    // System.out.println(iterator.next());
                    iterator.next();
                }
            }
            long et = System.nanoTime();
            testTimes.addTestTime(et - st);
            memoryUsages[i] = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1000;
        }
        return testTimes;
    }

    @Override
    public TestTimes runStackTestCase(StackType stackType, StackTestType stackTestType, int numberOfTimes) {
        TestTimes testTimes = new TestTimes();
        double[] memoryUsages = testTimes.getMemoryUsages();
        for (int i = 0; i < numberOfTimes; i++) {
            StackInterface<String> stack = createStack(stackType, stackTestType);
            long st = System.nanoTime();
            if (stackTestType == StackTestType.Push) {
                for (int j = 1; j <= 10000; j++) {
                    stack.push("String " + j);
                }
            } else if (stackTestType == StackTestType.Pop) {
                for (int j = 1; j <= 10000; j++) {
                    stack.pop();
                }
            } else {
                ElementIterator<String> iterator = (ElementIterator<String>) stack.iterator();
                while (iterator.hasNext()) {
                    // System.out.println(iterator.next());
                    iterator.next();
                }
            }
            long et = System.nanoTime();
            testTimes.addTestTime(et - st);
            memoryUsages[i] = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1000;
        }
        return testTimes;
    }

    public static void printTestTimes(TestTimes testTimes) {
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n|");
        for (int t = 0; t < 9; t++) {
            System.out.print("           |");
        }
        System.out.print("            | Average    |\n|");
        for (int t = 1; t <= 10; t++) {
            System.out.print(" run " + t + "     |");
        }
        System.out.print(" Micro      |\n|");
        for (int t = 0; t < 9; t++) {
            System.out.print("           |");
        }
        System.out.print("            | Seconds    |\n");
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n");
        for (int t = 0; t < 10; t++) {
            System.out.print("| " + String.format("%10.1f", testTimes.getTestTimes()[t] / 1000));
        }
        System.out.print(" | " + String.format("%11.1f", testTimes.getAverageTestTime() / 1000) + "|\n");
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n\n");
    }

    public static void printMemoryUsage(TestTimes testTimes) {
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n|");
        for (int t = 1; t <= 10; t++) {
            System.out.print(" run " + t + "     |");
        }
        System.out.print(" Average    |\n|");
        for (int t = 0; t < 9; t++) {
            System.out.print("           |");
        }
        System.out.print("            | Kilo bytes |\n");
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n");
        for (int t = 0; t < 10; t++) {
            System.out.print("| " + String.format("%10.1f", testTimes.getMemoryUsages()[t] / 1000));
        }
        System.out.print(" | " + String.format("%11.1f", testTimes.getAverageMemoryUsage() / 1000) + "|\n");
        for (int t = 0; t < 135; t++) {
            System.out.print("-");
        }
        System.out.print("\n\n");
    }
}