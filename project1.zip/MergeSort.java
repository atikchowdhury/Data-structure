
public class MergeSort<T extends java.lang.Comparable<? super T>> extends TestTimes implements SortInterface<T> {

  public MergeSort() {
  }

  @SuppressWarnings("unchecked")
  private void merge(T[] array, Object[] tempArray, int first, int mid, int last) {
    int i = first, j = mid + 1, k = 0;
    while (i <= mid && j <= last) {
      if (array[i].compareTo(array[j]) < 0)
        tempArray[k++] = array[i++];
      else
        tempArray[k++] = array[j++];
    }
    while (i <= mid)
      tempArray[k++] = array[i++];
    while (j <= last)
      tempArray[k++] = array[j++];
    k = 0;
    for (i = first; i <= last; i++)
      array[i] = (T) tempArray[k++];
  }

  private void mergesort(T[] array, Object[] tempArray, int first, int last) {
    if (first < last) {
      int mid = first + (last - first) / 2;
      for (int i = first; i <= last; i++)
        tempArray[i] = array[i];
      mergesort(array, tempArray, first, mid);
      mergesort(array, tempArray, mid + 1, last);
      merge(array, tempArray, first, mid, last);
    }
  }

  @Override
  public void sort(T[] arrayToSort) {
    Object[] tempArray = new Object[arrayToSort.length];
    for (int i = 0; i < tempArray.length; i++)
      tempArray[i] = null;
    mergesort(arrayToSort, tempArray, 0, arrayToSort.length - 1);
  }
}