
public class HeapSort<T extends Comparable<? super T>> implements SortInterface<T> {

  private T[] heap;
  private int heapSize;

  public HeapSort() {
  }

  private void heapify() {
    for (int i = heapSize / 2 - 1; i >= 0; i--)
      siftDown(i);
  }

  private void heapSort() {
    heapify();
    for (int i = heapSize - 1; i >= 0; i--) {
      T temp = heap[0];
      heap[0] = heap[i];
      heap[i] = temp;
      heapSize = i;
      siftDown(0);
    }
  }

  private void siftDown(int node) {
    int largest = node, left = 2 * node + 1, right = 2 * node + 2;
    if (left < heapSize && heap[left].compareTo(heap[largest]) > 0)
      largest = left;
    if (right < heapSize && heap[right].compareTo(heap[largest]) > 0)
      largest = right;
    if (largest != node) {
      T temp = heap[node];
      heap[node] = heap[largest];
      heap[largest] = temp;
      siftDown(largest);
    }
  }

  @Override
  public void sort(T[] arrayToSort) {
    heap = arrayToSort;
    heapSize = arrayToSort.length;
    heapSort();
  }
}