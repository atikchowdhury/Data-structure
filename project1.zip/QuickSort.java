
public class QuickSort<T extends Comparable<? super T>> implements SortInterface<T> {
  public static enum PivotType {
    FirstElement, RandomElement, MidOfFirstMidLastElement
  }

  private PivotType pivotType;

  public QuickSort() {
    pivotType = PivotType.FirstElement;
  }

  public void choosePivot(T[] array, int first, int last) {
    switch (pivotType) {
      case FirstElement:
        break;
      case MidOfFirstMidLastElement:
        T a = array[first];
        T b = array[first + (last - first) / 2];
        T c = array[last];
        if ((a.compareTo(b) < 0 && b.compareTo(c) < 0) || (c.compareTo(b) < 0 && b.compareTo(a) < 0))
          swap(array, first, first + (last - first) / 2);
        else if ((b.compareTo(a) < 0 && a.compareTo(c) < 0) || (c.compareTo(a) < 0 && a.compareTo(b) < 0))
          ;
        else
          swap(array, first, last);

        break;
      case RandomElement:
        int idx = first + (int) (Math.random() * ((last - first) + 1));
        swap(array, first, idx);
        break;
    }
  }

  public PivotType getPivotType() {
    return pivotType;
  }

  public void setPivotType(PivotType pivotType) {
    this.pivotType = pivotType;
  }

  private void swap(T[] array, int i, int j) {
    T temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }

  private void quickSort(T[] array, int first, int last) {
    if (first < last) {
      choosePivot(array, first, last);
      T pivot = array[first];
      int i = first + 1, j = last;
      while (i <= j) {
        while (i <= last && array[i].compareTo(pivot) <= 0) {
          i++;
        }
        while (j >= first && array[j].compareTo(pivot) > 0) {
          j--;
        }
        if (i < j)
          swap(array, i, j);
      }
      swap(array, first, j);
      quickSort(array, first, j - 1);
      quickSort(array, j + 1, last);
    }
  }

  @Override
  public void sort(T[] arrayToSort) {
    quickSort(arrayToSort, 0, arrayToSort.length - 1);
  }
}