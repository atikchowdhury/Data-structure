import java.util.Arrays;
import java.util.Collections;

public class Driver implements DriverInterface {
  private SortType sortType;

  public static void main(String[] args) {
    Driver driver = new Driver();
    for (ArrayType arrayType : ArrayType.values())
      for (SortType type : SortType.values()) {
        driver.sortType = type;
        driver.runSorts(arrayType, 1000, 10);
      }
    for (ArrayType arrayType : ArrayType.values())
      for (SortType type : SortType.values()) {
        driver.sortType = type;
        driver.runSorts(arrayType, 10000, 10);
      }
  }

  @Override
  public Integer[] createArray(ArrayType arrayType, int arraySize) {
    Integer[] array = new Integer[arraySize];
    switch (arrayType) {
      case Decreasing:
        for (int i = 0; i < arraySize; i++)
          array[i] = arraySize - i;
        break;
      case Equal:
        for (int i = 0; i < arraySize; i++)
          array[i] = arraySize;
        break;
      case Increasing:
        for (int i = 0; i < arraySize; i++)
          array[i] = i;
        break;
      case IncreasingAndRandom:
        int i = 0;
        for (i = 0; i < arraySize * 0.9; i++)
          array[i] = i;
        for (; i < arraySize; i++)
          array[i] = (int) (Math.random() * arraySize);
        break;
      case Random:
        for (i = 0; i < arraySize; i++)
          array[i] = i;
        Collections.shuffle(Arrays.asList(array));
        break;
      default:
        break;
    }
    return array;
  }

  @Override
  public TestTimes[] runSorts(ArrayType arrayType, int arraySize, int numberOfTimes) {
    Integer[] array = createArray(arrayType, arraySize);
    TestTimes[] testTimes = new TestTimes[numberOfTimes];
    for (int i = 0; i < numberOfTimes; i++) {
      long st = System.nanoTime();
      switch (sortType) {
        case HeapSort:
          HeapSort<Integer> heapSort = new HeapSort<>();
          heapSort.sort(array);
          break;
        case MergeSort:
          MergeSort<Integer> mergeSort = new MergeSort<>();
          mergeSort.sort(array);
          break;
        case QuickSort:
          QuickSort<Integer> quickSort = new QuickSort<>();
          quickSort.sort(array);
          break;
      }
      long end = System.nanoTime();
      testTimes[i].addTestTime(end - st);
    }
    return testTimes;
  }
}