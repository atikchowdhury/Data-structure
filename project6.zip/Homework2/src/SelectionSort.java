
public class SelectionSort extends TestTimes implements SortInterface {

    @Override
    
    public void sort(Integer[] arrayToSort) {
       
    	int n = arrayToSort.length;
       
    	long startTime = System.nanoTime();
       
    	for (int i = 0; i < n - 1; i++) {
           
    		int minIndex = i;
           
    		for (int j = i + 1; j < n; j++) {
                if (arrayToSort[j] < arrayToSort[minIndex]) {
                    minIndex = j;
                }
            }
           
    		int temp = arrayToSort[minIndex];
            
    		arrayToSort[minIndex] = arrayToSort[i];
            
    		arrayToSort[i] = temp;
        }
       
    	long endTime = System.nanoTime();
       
    	addTestTime(endTime - startTime);
    }
}