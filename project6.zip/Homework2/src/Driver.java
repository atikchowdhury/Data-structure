
public class Driver implements DriverInterface {

    public static void main(String[] args) {
    	
        Driver driver = new Driver();
        
        for (SortType sortType 
        		: SortType.values()) {
            int i = 0;
            
        while (i < 2) {
        TestTimes testTimes = null;
     for (ArrayType arrayType : ArrayType.values()) {
         if (i == 0) {
          System.out.println("SortType: " + sortType + ", ArrayType: " + arrayType + ", ArraySize: 1000");
          testTimes = driver.runSort(sortType, arrayType, 1000, 10);
           for (int t = 0; t < 111; t++) {
           System.out.print("-");
                  }
          System.out.print("\n|");
       for (int t = 0; t < 10; t++) {
        System.out.print(" runTime |");
            }
          System.out.println(" Average |");
           for (int t = 1; t <= 10; t++) {
            if (t != 10) {
         System.out.print("| " + t + "       ");
                } else {
                   System.out.print("| " + t + "      ");
                }
             }
                 System.out.println("| runTime |");
                        for (int t = 0; t < 111; t++) {
                            System.out.print("-");
                        }
                        System.out.println();
                        for (int t = 0; t < 10; t++) {
            System.out.print("| " + String.format("%8d", testTimes.getTestTimes()[t]));
               }
      System.out.println("|" + String.format("%9.1f", testTimes.getAverageTestTime()) + "|");
                        for (int t = 0; t < 111; t++) {
                            System.out.print("-");
                        }
                        System.out.println("\n");
                    } else { 
      System.out .println("SortType: " + sortType + ", ArrayType: " + arrayType + ", ArraySize: 10000");
                        testTimes = driver.runSort(sortType, arrayType, 10000, 10);
                        for (int t = 0; t < 122; t++) {
                            System.out.print("-");
                        }
                        System.out.print("\n|");
                        for (int t = 0; t < 10; t++) {
                            System.out.print(" runTime  |");
                        }
                        System.out.println(" Average   |");
                        for (int t = 1; t <= 10; t++) {
                            if (t != 10) {
                                System.out.print("| " + t + "        ");
                            } else {
                                System.out.print("| " + t + "       ");
                            }
                        }
                        System.out.println("| runTime   |");
                        for (int t = 0; t < 122; t++) {
                            System.out.print("-");
                        }
                        System.out.println();
                        for (int t = 0; t < 10; t++) {
                            System.out.print("| " + String.format("%9d", testTimes.getTestTimes()[t]));
                        }
                        System.out.println("|" + String.format("%11.1f", testTimes.getAverageTestTime()) + "|");
                        for (int t = 0; t < 122; t++) {
                            System.out.print("-");
                        }
                        System.out.println("\n");
                    }
                }
                i++;
            }
        }
    }

    @Override
    public Integer[] createArray(ArrayType arrayType, int arraySize) {
        Integer[] arrayToSort = new Integer[arraySize];
        switch (arrayType) {
        case Equal:
            for (int i = 0; i < arraySize; i++) {
                arrayToSort[i] = 1;
            }
            return arrayToSort;
        case Random:
            for (int i = 0; i < arraySize; i++) {
                arrayToSort[i] = (int) Math.random();
            }
            return arrayToSort;
        case Increasing:
            for (int i = 0; i < arraySize; i++) {
                arrayToSort[i] = i;
            }
            return arrayToSort;
        case Decreasing:
            for (int i = 0; i < arraySize; i++) {
                arrayToSort[i] = arraySize - i;
            }
            return arrayToSort;
        case IncreasingAndRandom:
            int s = (int) 0.9 * arraySize;
            for (int i = 0; i < s; i++) {
                arrayToSort[i] = i;
            }
            for (int i = s; i < arraySize; i++) {
                arrayToSort[i] = (int) Math.random();
            }
            return arrayToSort;
        default:
            return null;
        }
    }

    @Override
    public TestTimes runSort(SortType sortType, ArrayType arrayType, int arraySize, int numberOfTimes) {
        Integer[] arrayToSort;
        switch (sortType) {
        case BubbleSort:
            BubbleSort bubbleSort = new BubbleSort();
            for (int i = 0; i < numberOfTimes; i++) {
                arrayToSort = createArray(arrayType, arraySize);
                bubbleSort.sort(arrayToSort);
            }
            return bubbleSort;
        case InsertionSort:
            InsertionSort insertionSort = new InsertionSort();
            for (int i = 0; i < numberOfTimes; i++) {
                arrayToSort = createArray(arrayType, arraySize);
                insertionSort.sort(arrayToSort);
            }
            return insertionSort;
        case SelectionSort:
            SelectionSort selectionSort = new SelectionSort();
            for (int i = 0; i < numberOfTimes; i++) {
                arrayToSort = createArray(arrayType, arraySize);
                selectionSort.sort(arrayToSort);
            }
            return selectionSort;
        default:
            return null;
        }
    }
}