



import java.util.Vector;

public class Driver implements DriverInterface {

    public static void main(String[] args) {
        Driver driver = new Driver();
        Vector<TreeItem<Integer, String>> treeItems = driver.getVectorOfTreeItems();
        BinarySearchTree<Integer, String> bst = driver.createAndPopulateBST(treeItems);
        System.out.println("Height of the binary search tree is " + bst.height());
        bst.balance();
        System.out.println("Height of the balanced binary search tree is " + bst.height());
    }

    @Override
    public BinarySearchTree<Integer, String> createAndPopulateBST(Vector<TreeItem<Integer, String>> treeItems) {
        BinarySearchTree<Integer, String> bst = new BinarySearchTree<Integer, String>();
        for (int i = 0; i < treeItems.size(); i++) {
            try {
                bst.insert(treeItems.get(i));
            } catch (Exception e) {
                e.printStackTrace();
                return bst;
            }
        }
        return bst;
    }

    @Override
    public Vector<TreeItem<Integer, String>> getVectorOfTreeItems() {
        Vector<TreeItem<Integer, String>> treeItems = new Vector<TreeItem<Integer, String>>();
        int total = 131071;
        for (int i = 1; i <= total; i++) {
            int ran = (int) (Math.random() * total);
            TreeItem<Integer, String> treeItem = new TreeItem<Integer, String>(ran, "String " + ran);
            treeItems.add(treeItem);
        }
        return treeItems;
    }
}