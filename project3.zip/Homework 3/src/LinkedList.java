public class LinkedList<E> implements ListInterface<Integer> {

    private LinkedListNode<Integer> head = null;
    private LinkedListNode<Integer> tail = null;
    private int size = 0;

    @Override
    public void add(Integer element) {
        if (size == 0) {
            head = new LinkedListNode<Integer>(element, null);
            tail = head;
        } else {
            LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, null);
            tail.setNext(newNode);
            tail = newNode;
        }
        size++;
    }

    @Override
    public boolean add(Integer element, int index) {
        if (index < size && index != 0) {
            LinkedListNode<Integer> temp = head;
            int curr = 0;
            while (curr != index - 1) {
                temp = temp.getNext();
                curr++;
            }
            LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, temp.getNext());
            temp.setNext(newNode);
            size++;
            return true;
        } else if (index == size && index != 0) {
            LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, null);
            tail.setNext(newNode);
            tail = newNode;
            size++;
            return true;
        } else if (index == 0) {
            if (size != 0) {
                LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, head);
                head = newNode;
            } else {
                LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, null);
                head = newNode;
                tail = head;
            }
            size++;
            return true;
        }
        return false;
    }

    @Override
    public void addSorted(Integer element) {
        if (size == 0 || (size > 0 && tail.getData() <= element)) {
            LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, null);
            if (size == 0) {
                head = newNode;
                tail = head;
            } else {
                tail.setNext(newNode);
                tail = newNode;
            }
            size++;
        } else {
            LinkedListNode<Integer> temp = head;
            if (head.getData() <= element) {
                while (temp.getNext() != null && temp.getNext().getData() <= element) {
                    temp = temp.getNext();
                }
                LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, temp.getNext());
                temp.setNext(newNode);
            } else {
                LinkedListNode<Integer> newNode = new LinkedListNode<Integer>(element, head.getNext());
                head = newNode;
            }
            size++;
        }
    }

    @Override
    public Integer get(int index) {
        if (index < size) {
            LinkedListNode<Integer> temp = head;
            int curr = 0;
            while (curr != index) {
                temp = temp.getNext();
                curr++;
            }
            return temp.getData();
        }
        return null;
    }

    @Override
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean remove(int index) {
        if (index < size && index != 0) {
            LinkedListNode<Integer> temp = head;
            int curr = 0;
            while (curr != index - 1) {
                temp = temp.getNext();
                curr++;
            }
            LinkedListNode<Integer> newNode = temp.getNext().getNext();
            temp.setNext(newNode);
            size--;
            return true;
        } else if (index == 0 && size != 0) {
            if (size == 1) {
                head = null;
                tail = null;
            } else {
                head = head.getNext();
            }
            size--;
            return true;
        }
        return false;
    }

    @Override
    public void removeAll() {
        head = null;
        tail = null;
    }

    @Override
    public Integer replace(Integer element, int index) {
        if (index < size) {
            LinkedListNode<Integer> temp = head;
            int curr = 0;
            while (curr != index) {
                temp = temp.getNext();
                curr++;
            }
            temp.setData(element);
            return temp.getData();
        }
        return null;
    }

    @Override
    public int size() {
        return size;
    }

}