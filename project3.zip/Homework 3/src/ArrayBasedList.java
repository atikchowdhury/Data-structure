public class ArrayBasedList<E> implements ListInterface<Integer> {

    private Integer[] list = new Integer[100000];
    private int size = 0;

    @Override
    public void add(Integer element) {
        list[size++] = element;
    }

    @Override
    public boolean add(Integer element, int index) {
        if (index < size) {
            Integer temp = list[index], temp2;
            list[index] = element;
            for (int i = index + 1; i < size; i++) {
                temp2 = list[i];
                list[i] = temp;
                temp = temp2;
            }
            list[size++] = temp;
            return true;
        } else if (index == size) {
            list[size++] = element;
            return true;
        }
        return false;
    }

    @Override
    public void addSorted(Integer element) {
        if (size == 0 || (size > 0 && list[size - 1] <= element)) {
            list[size++] = element;
        } else {
            int i;
            for (i = 0; i < size; i++) {
                if (list[i] > element) {
                    break;
                }
            }
            int temp = list[i], temp2;
            list[i] = element;
            for (int j = i + 1; j < size; j++) {
                temp2 = list[j];
                list[j] = temp;
                temp = temp2;
            }
            list[size++] = temp;
        }
    }

    @Override
    public Integer get(int index) {
        if (index < size) {
            return list[index];
        } else {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean remove(int index) {
        if (index < size) {
            list[index] = null;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void removeAll() {
    	Integer [] list = new Integer[100000];
        list = null;
    }

    @Override
    public Integer replace(Integer element, int index) {
        if (index < size && list[index] != null) {
            list[index] = element;
            return list[index];
        }
        return null;
    }

    @Override
    public int size() {
        return size;
    }

}