public class Driver implements DriverInterface {

    private static final int mb = 1000000;

    public static void main(String[] args) {
        Driver driver = new Driver();
        for (TestType testType : TestType.values()) {
            System.out.println("Running test = " + testType.toString());
            for (ListType listType : ListType.values()) {
                System.out.println(listType.toString());
                TestTimes testTimes = driver.runTestCase(listType, testType, 10);
                for (int t = 0; t < 149; t++) {
                    System.out.print("-");
                }
                System.out.print("\n|");
                for (int t = 1; t <= 10; t++) {
                    System.out.print(" run " + t + "     |");
                }
                System.out.print(" Average    | Memory Usage|\n|");
                for (int t = 0; t < 9; t++) {
                    System.out.print("           |");
                }
                System.out.print("            | Seconds    | Mega Bytes  |\n");
                for (int t = 0; t < 149; t++) {
                    System.out.print("-");
                }
                System.out.print("\n");
                for (int t = 0; t < 10; t++) {
                    System.out.print("| " + String.format("%10d", testTimes.getTestTimes()[t]));
                }
                System.out.print(" | " + String.format("%11.1f", testTimes.getAverageTestTime()) + "|"
                        + String.format("%13.6f", driver.memoryUsage()) + "|\n");
                for (int t = 0; t < 149; t++) {
                    System.out.print("-");
                }
                System.out.print("\n\n");
            }
        }
    }

    @Override
    public ListInterface<Integer> createList(ListType listType, TestType forTestType) {
        switch (listType) {
            case ArrayBasedList:
                ListInterface<Integer> list = new ArrayBasedList<Integer>();
                int i;
                switch (forTestType) {
                    case AddSortedOdd:
                        for (i = 1; i <= 9999; i += 2) {
                            list.addSorted(i);
                        }
                        break;
                    case AddSortedEven:
                        for (i = 2; i <= 10000; i += 2) {
                            list.addSorted(i);
                        }
                        break;
                    case AddAll:
                        list = initializeList(list, 1, 10000, 1);
                        break;
                    case AddAllAtIndexZero:
                        for (i = 1; i <= 10000; i++) {
                            list.add(i, 0);
                        }
                        break;
                    case RemoveAllEven:
                        list = initializeList(list, 1, 10000, 1);
                        for (i = 1; i < 10000; i += 2) {
                            list.remove(i);
                        }
                        break;
                    case RemoveAllOdd:
                        list = initializeList(list, 1, 10000, 1);
                        for (i = 0; i < 9999; i += 2) {
                            list.remove(i);
                        }
                        break;
                }
                return list;
            case LinkedList:
                ListInterface<Integer> llist = new LinkedList<Integer>();
                switch (forTestType) {
                    case AddSortedOdd:
                        for (i = 1; i <= 9999; i += 2) {
                            llist.addSorted(i);
                        }
                        break;
                    case AddSortedEven:
                        for (i = 2; i <= 10000; i += 2) {
                            llist.addSorted(i);
                        }
                        break;
                    case AddAll:
                        for (i = 1; i <= 10000; i++) {
                            llist.add(i);
                        }
                        break;
                    case AddAllAtIndexZero:
                        for (i = 1; i <= 10000; i++) {
                            llist.add(i, 0);
                        }
                        break;
                    case RemoveAllEven:
                        for (i = 1; i <= 10000; i++) {
                            llist.add(i);
                        }
                        for (i = 1; i < 10000; i += 2) {
                            llist.remove(i);
                        }
                        break;
                    case RemoveAllOdd:
                        for (i = 1; i <= 10000; i++) {
                            llist.add(i);
                        }
                        for (i = 0; i < 9999; i += 2) {
                            llist.remove(i);
                        }
                        break;
                }
                return llist;
            default:
                return null;
        }
    }

    @Override
    public ListInterface<Integer> initializeList(ListInterface<Integer> list, int firstNumber, int lastNumber,
            int increment) {
        for (int i = firstNumber; i <= lastNumber; i += increment) {
            list.add(i);
        }
        return list;
    }

    @Override
    public double memoryUsage() {
        long memUsed = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        return (double) memUsed / mb;
    }

    @Override
    public TestTimes runTestCase(ListType listType, TestType testType, int numberOfTimes) {
        TestTimes testTimes = new TestTimes();
        for (int i = 0; i < numberOfTimes; i++) {
            long st = System.nanoTime();
            createList(listType, testType);
            long et = System.nanoTime();
            testTimes.addTestTime(et - st);
        }
        return testTimes;
    }
}