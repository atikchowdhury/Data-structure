public class TestTimes implements TestTimesInterface {

    private long[] arr = new long[10];
    private int counter = 0;

    @Override
    public void addTestTime(long testTime) {
        if (counter < 10) {
            arr[counter++] = testTime;
        } else {
            for (int i = 1; i < 9; i++) {
                arr[i] = arr[i - 1];
            }
            arr[9] = testTime;
        }
    }

    @Override
    public double getAverageTestTime() {

        long total = 0;

        if (counter > 0) {

            for (int i = 0; i < counter; i++) {
                total += arr[i];
            }
            return (double) total / counter;
        }
        return 0;
    }

    @Override
    public long getLastTestTime() {
        if (counter > 0) {
            return arr[counter - 1];
        }
        return 0;

    }

    @Override
    public long[] getTestTimes() {
        return arr;
    }

    @Override
    public void resetTestTimes() {
        for (int i = 0; i < 10; i++) {
            arr[i] = 0;
        }
    }
}