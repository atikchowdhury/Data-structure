public class LinkedListNode<I extends java.lang.Comparable<? super I>> {
    private I data;
    private LinkedListNode<I> next;

    LinkedListNode(I data) {
        this.data = data;
    }

    LinkedListNode(I data, LinkedListNode<I> next) {
        this.data = data;
        this.next = next;
    }

    public I getData() {
        return data;
    }

    public LinkedListNode<I> getNext() {
        return next;
    }

    public void setData(I data) {
        this.data = data;
    }

    public void setNext(LinkedListNode<I> next) {
        this.next = next;
    }
}