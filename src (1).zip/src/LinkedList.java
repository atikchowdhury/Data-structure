public class LinkedList<E extends KeyedElementInterface<K>, K> implements ListInterface<E, K> {

    private LinkedListNode<E, K> head;
    private LinkedListNode<E, K> tail;
    private int size;

    public LinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E add(E element) {
        E removed = remove(element.getKey());
        LinkedListNode<E, K> newNode = new LinkedListNode<>(element);
        if (head == null) {
            head = newNode;
        }
        else {
            tail.setNext(newNode);
        }
        tail = newNode;
        size++;
        return removed;
    }

    @Override
    public E get(K key) {
        LinkedListNode<E, K> current = head;
        while (current != null) {
            E element = current.getData();
            if (element.getKey().equals(key)) {
                return element;
            }
            current = current.getNext();
        }
        return null;
    }

    @Override
    public E replace(E element) {
        LinkedListNode<E, K> current = head;
        K key = element.getKey();
        while (current != null) {
            E e = current.getData();
            if (e.getKey().equals(key)) {
                current.setData(element);
                return e;
            }
            current = current.getNext();
        }
        return null;
    }

    @Override
    public E remove(K key) {
        if (head == null) {
            return null;
        }
        if (head.getData().getKey().equals(key)) {
            E element = head.getData();
            head = head.getNext();
            if (head == null) {
                tail = null;
            }
            size--;
            return element;
        }
        LinkedListNode<E, K> current = head;
        while (current.getNext() != null) {
            if (current.getNext().getData().getKey().equals(key)) {
                if (current.getNext() == tail) {
                    tail = current;
                }
                E element = current.getData();
                current.setNext(current.getNext().getNext());
                size--;
                return element;
            }
            current = current.getNext();
        }
        return null;
    }

    @Override
    public void removeAll() {
        head = null;
        tail = null;
        size = 0;
    }
}
