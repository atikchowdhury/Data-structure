public class LinkedListNode<E extends KeyedElementInterface<K>, K> {
    private E data;
    private LinkedListNode<E, K> next;

    LinkedListNode(E data) {
        this.data = data;
    }

    public E getData() {
        return data;
    }

    public LinkedListNode<E, K> getNext() {
        return next;
    }

    public void setData(E data) {
        this.data = data;
    }

    public void setNext(LinkedListNode<E, K> next) {
        this.next = next;
    }
}
