import java.util.*;

public class HashTable<E extends KeyedElementInterface<K>, K> implements HashTableInterface<E, K> {
    public static final int NUMBER_OF_BUCKETS = 1_069;

    private LinkedList<E, K>[] buckets;
    private int size = 0;

    public HashTable() {
        this.buckets = new LinkedList[NUMBER_OF_BUCKETS];
        for (int i = 0; i<NUMBER_OF_BUCKETS; i++) {
            buckets[i] = new LinkedList<>();
        }
    }

    public HashTable(LinkedList<E, K>[] buckets) throws InstantiationException {
        if (buckets.length != NUMBER_OF_BUCKETS) {
            throw new InstantiationException();
        }
        this.buckets = buckets.clone();
    }


    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E insert(E element) {
        int hash = getHash(element.getKey());
        if (buckets[hash] == null) {
            buckets[hash] = new LinkedList<>();
        }
        E replaced = buckets[hash].add(element);
        if (replaced == null) {
            size++;
        }
        return replaced;
    }

    @Override
    public E get(K key) {
        int hash = getHash(key);
        if (buckets[hash] != null) {
            return buckets[hash].get(key);
        }
        return null;
    }

    @Override
    public E remove(K key) {
        int hash = getHash(key);
        if (buckets[hash] != null) {
            E removed = buckets[hash].remove(key);
            if (removed != null) {
                size--;
            }
            return removed;
        }
        return null;
    }

    @Override
    public void removeAll() {
        for(int i = 0; i<NUMBER_OF_BUCKETS; i++) {
            buckets[i] = null;
        }
        size = 0;
    }

    @Override
    public int getSizeOfLargestBucket() {
        return Arrays.stream(buckets).filter(Objects::nonNull).mapToInt(LinkedList::size).max().orElse(0);
    }

    @Override
    public double getAverageBucketSize() {
        return Arrays.stream(buckets).filter(Objects::nonNull).mapToInt(LinkedList::size).average().orElse(0.0);
    }

    @Override
    public LinkedList<E, K>[] getBuckets() {
        return buckets;
    }


    @Override
    public Iterator<E> iterator() {
        return null;
    }

    private int getHash(K key) {
        return key.hashCode() % NUMBER_OF_BUCKETS;
    }

    public static void main(String[] args) {
        Vector<Person<Integer>> persons = new Vector<>();
        for (int i = 0; i<100000; i++) {
            persons.add(new Person<>(i));
        }

        HashTable<Person<Integer>, Integer> hashTable = new HashTable<>();
        for (Person<Integer> person : persons) {
            hashTable.insert(person);
        }

        for (Person<Integer> person : persons) {
            if (hashTable.get(person.getKey()) == null) {
                throw new IllegalStateException();
            }
        }

        int counter = 100000;
        for (Person<Integer> person : persons) {
            if (hashTable.remove(person.getKey()) == null) {
                throw new IllegalStateException();
            }
            counter--;
            if (hashTable.size() != counter) {
                throw new IllegalStateException();
            }
        }

        if (!hashTable.isEmpty()) {
            throw new IllegalStateException();
        }

    }
}
