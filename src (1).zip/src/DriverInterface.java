public interface DriverInterface {
	
	/**
	 * 
	 * This <code>enum</code> is used to specify which test scenario will be executed.
	 * 
	 * The <code>TestType</code> enum has the following choices:
	 * 							<ol>
	 * 								<li>Insert</li>
	 * 								<li>Get</li>
 	 * 								<li>Remove</li>
	 * 							</ol>
	 *
	 */
	public static enum TestType {Insert, Get, Remove};
	
	/**
	 *
	 * This method is used to create array with the 
	 * specified number of <code>Person&lt;Integer&gt;</code> instances.
	 * 
	 * @param numPeople	The number of <code>Person&lt;Integer&gt;</code> instances to create.
	 * 
	 * @return	This method returns a <code>Vector&lt;Person&lt;Integer&gt;&gt;</code> with the 
	 * 			specified number of <code>Person&lt;Integer&gt;</code> instances.
	 */
	public Person<Integer>[] createPersons(int numPeople);
	
	/**
	 * 
	 * This method create the buckets that are needed for the
	 * <code>HashTable&lt;Person&lt;Integer&gt;, Integer&gt;</code>.
	 * 
	 * @param numBuckets	The number of buckets needed for the <code>HashTable&lt;Person&lt;Integer&gt;, Integer&gt;</code>.
	 * 	
	 * @return	An array of <code>LinkedList&lt;Person&lt;Integer&gt;, Integer$gt;</code> containing the specified number
	 * 			of <code>LinkedList&lt;Person&lt;Integer&gt;, Integer$gt;</code> instances.
	 */
	public LinkedList<Person<Integer>, Integer>[] createBuckets(int numBuckets);
	
	/**
	 * 
	 * This method is used to create a <code>HashTable&lt;Person&lt;Integer&gt;, Integer&gt;</code>
	 * for the specified <b>testType</b>.
	 * 
	 * @param testType	The type of test for the created HashTable.
	 * 					<dl>
	 * 						<dt>
	 * 							Insert
	 * 						</dt>
	 * 						<dd>
	 * 							The returned HashTable must be empty
	 * 						</dd>
	 * 						<dt>
	 * 							Get
	 * 						</dt>
	 * 						<dd>
	 * 							The returned HashTable must contain the specified number of 
	 * 							<code>Person&lt;Integer&gt;</code> instances.
	 * 						</dd>
	 * 						<dt>
	 * 							Remove
	 * 						</dt>
	 * 						<dd>
	 * 							The returned HashTable must contain the specified number of 
	 * 							<code>Person&lt;Integer&gt;</code> instances.
	 * 						</dd>
	 * 					</dl>
	 * @param numPeople	The number of <code>Person&lt;Integer&gt;</code> instances to include in
	 * 					the returned HashTable.
	 * 
	 * @return			This method will return an instance of <code>HashTable&lt;Person&lt;Integer&gt;, Integer&gt;</code>
	 * 					containing the specified number of <code>Person&lt;Integer&gt;</code> instances
	 */
	public HashTable<Person<Integer>, Integer> createHashTable(TestType testType, int numPeople);
	
	/**
	 * This method is called to run a particular test case on the <code>HashTable&lt;Person&lt;Integer&gt;, Integer&gt;</code>
	 * the specified number of times. The run time 	 * and memory usage for each run is saved in the TestTimes class.
	 * 
	 * @param testType		The test type to be run.
	 * @param numPeople		The number of <code>Person&lt;Integer&gt;</code> instances to include 
	 * 						in the test.
	 * @param numberOfTimes The type of test case being run. See the enum {@link TestType}.
	 * @return	An instance of the <code>TestTimes</code> class containing the test times and memory usages.
	 */
	public TestTimes runTestCase(TestType testType, int numPeople, int numberOfTimes);
}
