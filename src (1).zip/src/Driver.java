public class Driver implements DriverInterface {
    @Override
    public Person<Integer>[] createPersons(int numPeople) {
        Person<Integer>[] persons = new Person[numPeople];
        for (int i = 0; i < numPeople; i++) {
            persons[i] = new Person<>(i);
        }
        return persons;
    }

    @Override
    public LinkedList<Person<Integer>, Integer>[] createBuckets(int numBuckets) {
        LinkedList<Person<Integer>, Integer>[] buckets = new LinkedList[numBuckets];
        for (int i = 0; i < numBuckets; i++) {
            buckets[i] = new LinkedList<>();
        }
        return buckets;
    }

    @Override
    public HashTable<Person<Integer>, Integer> createHashTable(TestType testType, int numPeople) {
        LinkedList<Person<Integer>, Integer>[] buckets = createBuckets(HashTable.NUMBER_OF_BUCKETS);
        Person<Integer>[] persons = createPersons(numPeople);
        try {
            HashTable<Person<Integer>, Integer> hashTable = new HashTable<>(buckets);
            switch (testType) {
                case Get:
                case Remove:
                    for (Person<Integer> person : persons) {
                        hashTable.insert(person);
                    }
                case Insert:
                    return hashTable;

                default:
                    return null;
            }
        } catch (InstantiationException e) {
            return null;
        }
    }

    @Override
    public TestTimes runTestCase(TestType testType, int numPeople, int numberOfTimes) {
        TestTimes testTimes = new TestTimes();
        testTimes.setTimeUnits(TestTimesInterface.TimeUnits.MicroSeconds);
        testTimes.setMemoryUnits(TestTimesInterface.MemoryUnits.KiloBytes);
        for (int i = 0; i < numberOfTimes; i++) {
            HashTable<Person<Integer>, Integer> hashTable = createHashTable(testType, numPeople);
            Person<Integer>[] persons = createPersons(numPeople);
            long startTime = System.nanoTime();
            switch (testType) {
                case Insert:
                    for (Person<Integer> person : persons) {
                        hashTable.insert(person);
                    }
                    break;
                case Get:
                    for (Person<Integer> person : persons) {
                        hashTable.get(person.getKey());
                    }
                    break;
                case Remove:
                    for (Person<Integer> person : persons) {
                        hashTable.remove(person.getKey());
                    }
                    break;
            }
            long totalTime = (System.nanoTime() - startTime)/1000;
            testTimes.addTestTime(totalTime);
        }
        return testTimes;
    }

    public static void main(String[] args) {
        Driver driver = new Driver();
        int numberOfTimes = 10;

        StringBuilder builder = new StringBuilder();
        builder.append(String.format("%9s",""));
        for (int i = 1; i<= numberOfTimes; i++) {
            builder.append(String.format("%6s  ", ("Run " + i)));
        }
        builder.append("Average").append(System.lineSeparator());

        builder.append(String.format("%9s",""));
        for (int i = 1; i<= numberOfTimes+1; i++) {
            builder.append(String.format("%6s  ", "Micro"));
        }
        builder.append(System.lineSeparator());

        builder.append(String.format("%9s",""));
        for (int i = 1; i<= numberOfTimes+1; i++) {
            builder.append("Seconds ");
        }
        builder.append(System.lineSeparator());

        builder.append(String.format("%9s",""));
        for (int i = 1; i<= numberOfTimes+1; i++) {
            builder.append("------- ");
        }
        builder.append(System.lineSeparator());


        for (TestType type : TestType.values()) {
            TestTimes testTimes = driver.runTestCase(type, 100000, numberOfTimes);
            builder.append(String.format("%-9s",type.toString()));
            for (int i = 0; i<numberOfTimes; i++) {
                builder.append(String.format("%7s ", String.format("%.0f", testTimes.getTestTimes()[i])));
            }
            builder.append(String.format("%7s  ", String.format("%.1f", testTimes.getAverageTestTime())));
            builder.append(System.lineSeparator());
        }
        System.out.println(builder);
    }
}
